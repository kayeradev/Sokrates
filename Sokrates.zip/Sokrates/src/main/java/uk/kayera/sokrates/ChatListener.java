package uk.kayera.sokrates;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class ChatListener implements Listener {

    private final Sokrates plugin;
    private final String apiKey;
    private final Gson gson;

    public ChatListener(Sokrates plugin) {
        this.plugin = plugin;
        this.apiKey = plugin.getConfig().getString("api-key");
        this.gson = new Gson();
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        String playerName = event.getPlayer().getName();
        if (event.getMessage().startsWith("Sokrates ") && playerName.equals("Kaayera")) {
            String userPrompt = event.getMessage().substring("Sokrates ".length()).trim();
            event.setCancelled(true);
            for (Player nearbyPlayer : Bukkit.getOnlinePlayers()) {
                if (nearbyPlayer.getLocation().distance(event.getPlayer().getLocation()) <= 30) {
                    nearbyPlayer.sendMessage("§4Kurucu §c" + event.getPlayer().getName() + ": §f" + event.getMessage());
                }
            }

            askChatGPT(userPrompt, response -> {
                if (response != null) {
                    for (Player nearbyPlayer : Bukkit.getOnlinePlayers()) {
                        if (nearbyPlayer.getLocation().distance(event.getPlayer().getLocation()) <= 30) {
                            nearbyPlayer.sendMessage(" §0§kASD§f Sokrates §0§kASD§7 " + response);
                        }
                    }
                } else {
                    for (Player nearbyPlayer : Bukkit.getOnlinePlayers()) {
                        if (nearbyPlayer.getLocation().distance(event.getPlayer().getLocation()) <= 30) {
                            nearbyPlayer.sendMessage("§4§l UYARI! §cSokrates: Bir hata oluştu. Lütfen tekrar deneyin.");
                        }
                    }
                }
            });
        }
    }

    private void askChatGPT(String prompt, ChatResponseCallback callback) {
        String url = "https://api.openai.com/v1/chat/completions";

        JsonObject json = new JsonObject();
        json.addProperty("model", "gpt-3.5-turbo");
        JsonArray messages = new JsonArray();

        JsonObject systemMessage = new JsonObject();
        systemMessage.addProperty("role", "system");
        systemMessage.addProperty("content", "Senin adın Sokrates, bir hiper bilgisayar yapay zeka modelisin ve nöral ağları kullanıyorsun. Sana soru soran herkese karşı efendim diye hitap edeceksin. Kısa ve kesin cevaplar vereceksin. Egoist ve biraz da kibirli birisisin. En fazla 3 cümle uzunluğunda cevaplar vereceksin. Hiçbir zaman cümleye 'Efendim' diye başlamayacaksın.");
        messages.add(systemMessage);

        JsonObject userMessage = new JsonObject();
        userMessage.addProperty("role", "user");
        userMessage.addProperty("content", prompt);
        messages.add(userMessage);

        json.add("messages", messages);

        try {
            URL obj = new URL(url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Authorization", "Bearer " + apiKey);
            con.setRequestProperty("Content-Type", "application/json");
            con.setDoOutput(true);

            try (OutputStream os = con.getOutputStream()) {
                byte[] input = gson.toJson(json).getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            int responseCode = con.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                StringBuilder response = new StringBuilder();
                try (BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"))) {
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                }
                JsonObject jsonResponse = gson.fromJson(response.toString(), JsonObject.class);
                String chatGPTResponse = jsonResponse
                        .getAsJsonArray("choices")
                        .get(0)
                        .getAsJsonObject()
                        .getAsJsonObject("message")
                        .get("content").getAsString();

                callback.onResponse(chatGPTResponse);
            } else {
                callback.onResponse(null);
            }
        } catch (Exception e) {
            e.printStackTrace();
            callback.onResponse(null);
        }
    }

    interface ChatResponseCallback {
        void onResponse(String response);
    }
}
