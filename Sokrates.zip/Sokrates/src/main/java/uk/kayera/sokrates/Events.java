package uk.kayera.sokrates;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Collections;

public class Events implements Listener {
    private final Sokrates plugin;
    private final double DISPLAY_BLOCK_DISTANCE = 2.5;
    private ArmorStand armorStand;

    private final Material[] blockTypes = {
            Material.DIAMOND_BLOCK,
            Material.LAPIS_BLOCK,
            Material.BEDROCK,
            Material.GLASS
    };
    private BukkitRunnable blockChangeRunnable;


    public Events(Sokrates plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.getName().equalsIgnoreCase("Kaayera")) {
            createArmorStand(player);
        }
        if (player.getName().equalsIgnoreCase("Kaayera")) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    updateArmorStand(player);
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }
        if (player.getName().equalsIgnoreCase("Kaayera")) {
            new BukkitRunnable() {
                @Override
                public void run() {
                    for (Player nearbyPlayer : player.getWorld().getPlayers()) {
                        if (nearbyPlayer.getLocation().distance(armorStand.getLocation()) <= 30) {
                            if (nearbyPlayer.getName().equals("Kaayera")) {
                                nearbyPlayer.sendActionBar("§fAdmin Panel §b§l| §fStatus: §bActive §7(" + Math.round(nearbyPlayer.getLocation().distance(armorStand.getLocation())) + "§7)");
                            } else {
                                nearbyPlayer.sendActionBar("§0§kASD§f Sokrates §0§kASD§f: Artificial intelligence model using standard neural network.");
                            }
                        }
                    }
                }
            }.runTaskTimer(plugin, 0L, 5L);
        }
    }


    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (player.getName().equalsIgnoreCase("Kaayera")) {
            removeArmorStand();
        }
    }

    public void startBlockChange(ArmorStand armorStand) {
        blockChangeRunnable = new BukkitRunnable() {
            @Override
            public void run() {
                Material randomBlock = blockTypes[(int) (Math.random() * blockTypes.length)];
                ItemStack enchantedBlock = new ItemStack(randomBlock);

                // Büyü ekle
                ItemMeta meta = enchantedBlock.getItemMeta();
                if (meta != null) {
                    meta.addEnchant(org.bukkit.enchantments.Enchantment.MENDING, 1, true);
                    enchantedBlock.setItemMeta(meta);
                }

                armorStand.setHelmet(enchantedBlock);
            }
        };
        blockChangeRunnable.runTaskTimer(plugin, 1L, 5L);
    }




    public void updateArmorStand(Player player) {
        if (armorStand != null) {
            Location targetLocation = getDisplayLocation(player);
            if (!armorStand.getLocation().equals(targetLocation)) {
                Location currentLocation = armorStand.getLocation();
                armorStand.teleport(new Location(
                        armorStand.getWorld(),
                        targetLocation.getX(),
                        targetLocation.getY() - 1.5,
                        targetLocation.getZ(),
                        currentLocation.getYaw(),
                        currentLocation.getPitch()
                ));
            }

            armorStand.setRotation(armorStand.getLocation().getYaw() + 1.5f, armorStand.getLocation().getPitch());
        }
    }



    private Location getDisplayLocation(Player player) {
        Location playerLocation = player.getLocation();
        return playerLocation.clone().add(DISPLAY_BLOCK_DISTANCE, 0, 0);
    }

    private void createArmorStand(Player player) {
        armorStand = player.getWorld().spawn(player.getLocation().add(DISPLAY_BLOCK_DISTANCE, 0, 0), ArmorStand.class);
        armorStand.setVisible(false);
        armorStand.setGravity(false);
        armorStand.setCustomName("§0§kASD§f Sokrates §0§kASD§f");
        armorStand.setCustomNameVisible(true);

        ItemStack diamondBlock = new ItemStack(Material.DIAMOND_BLOCK);
        ItemMeta meta = diamondBlock.getItemMeta();
        if (meta != null) {
            meta.addEnchant(org.bukkit.enchantments.Enchantment.MENDING, 1, true);
            diamondBlock.setItemMeta(meta);
        }
        armorStand.setHelmet(diamondBlock);

        startBlockChange(armorStand);
    }


    private void removeArmorStand() {
        if (armorStand != null) {
            armorStand.remove();
            armorStand = null;
        }
    }
}
