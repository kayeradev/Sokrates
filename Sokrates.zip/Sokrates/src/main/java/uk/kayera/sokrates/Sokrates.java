package uk.kayera.sokrates;

import org.bukkit.plugin.java.JavaPlugin;

public class Sokrates extends JavaPlugin {
    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new Events(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getConsoleSender().sendMessage("§aSokrates enabled.");
        getServer().getConsoleSender().sendMessage("§aEvents ve ChatListener kayıt edildi.");
    }


    @Override
    public void onDisable() {
        getServer().getConsoleSender().sendMessage("§aSokrates disabled.");
    }
}